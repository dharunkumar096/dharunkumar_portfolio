---
name: "Healthcare Claim Adjudication GenAI Assistant"
summary: "RAG-powered assistant for claim documents, policy retrieval, claim reasoning, missing-document alerts, and adjudication recommendations."
role: "AI Engineer"
timeline: "2026"
category: "real-time"
stackNote: "Python, LangChain, Azure OpenAI, Llama 3, FAISS, Redis, Celery, MLflow, Prometheus, Grafana"
tags: ["Python", "RAG", "Azure OpenAI", "LangChain", "FAISS", "Healthcare AI"]
---

## Overview

Built document ingestion and retrieval workflows for claim forms, medical bills, discharge summaries, and adjudication guidelines.

## Key capabilities

- Embedding-based retrieval over policy clauses, member eligibility, CPT/ICD descriptions, and medical guidelines.
- Prompt workflows for claim summaries, approval/denial reasoning, missing-document alerts, and adjudication recommendations.
- Redis-based conversational memory for multi-turn, context-aware claim analysis.
- Celery batch processing for large claim volumes.
- MLflow and Prometheus/Grafana monitoring for prompt versions, outputs, and response quality.
