---
name: "Banking Fraud Alert & Risk Scoring Platform"
summary: "Event-driven multi-agent fraud analysis and risk scoring platform with RAG over AML rules, fraud patterns, and compliance policies."
role: "AI Engineer"
timeline: "2026"
category: "real-time"
stackNote: "Python, FastAPI, LangGraph, AWS Bedrock, OpenSearch, DynamoDB, CloudWatch, RAGAS"
tags: ["Python", "LangGraph", "RAG", "AWS Bedrock", "OpenSearch", "Fraud Detection"]
---

## Overview

Designed an event-driven multi-agent workflow for fraud classification, risk scoring, rule validation, customer profiling, and case recommendations.

## Key capabilities

- RAG retrieval over AML rules, fraud patterns, and compliance policy documents using Amazon Titan Embeddings and OpenSearch Vector Database.
- Bedrock Claude integration for fraud investigation summaries, risk explanations, and suspicious activity narratives.
- Guardrails against unsafe recommendations, hallucinated compliance statements, and unauthorized data exposure.
- RAGAS evaluation covering faithfulness, answer relevance, context precision, and context recall.
