---
name: "Brain Tumor Detection Using Deep Learning"
summary: "MRI image classification application using a VGG16-based deep learning model to identify brain tumor categories."
role: "Machine Learning Developer"
timeline: "Academic Project"
category: "academic"
stackNote: "Python, TensorFlow, Keras, VGG16, OpenCV, Flask"
tags: ["Python", "TensorFlow", "Keras", "VGG16", "Computer Vision"]
---

## Overview

Built an MRI image classification application to identify brain tumor categories with a VGG16-based model.

## Key capabilities

- Preprocessing, augmentation, and feature extraction for MRI training and inference.
- Flask interface for uploading MRI images and viewing prediction results.
