---
name: "Steel Surface Defect Detection"
summary: "Computer vision system for detecting and classifying defects in steel surface images with segmentation-based location analysis."
role: "Machine Learning Developer"
timeline: "Academic Project"
category: "academic"
stackNote: "Python, PyTorch, Deep Learning, Image Segmentation"
tags: ["Python", "PyTorch", "Computer Vision", "Image Segmentation"]
---

## Overview

Built a computer vision system to detect and classify defects in steel surface images.

## Key capabilities

- Defect classification for automated visual inspection.
- Segmentation-based location analysis to identify where defects occur in the surface image.
