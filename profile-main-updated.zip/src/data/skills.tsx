import {
  Code2, Layers, Globe, Zap, Database, Server, Wrench, Activity,
  Cpu, ShieldCheck, BookOpen, Sparkles
} from "lucide-react";
import type { ElementType } from "react";
import type { SkillGroup } from "@/types";

export type SkillIconMeta = { icon: ElementType; color: string };

export const SKILL_ICON_MAP: Record<string, SkillIconMeta> = {
  Python: { icon: Code2, color: "#3776ab" },
  LLMs: { icon: Sparkles, color: "#a78bfa" },
  RAG: { icon: Layers, color: "#60a5fa" },
  "Prompt Engineering": { icon: Sparkles, color: "#f59e0b" },
  "Tool Calling": { icon: Wrench, color: "#34d399" },
  "Semantic Search": { icon: Globe, color: "#60a5fa" },
  Embeddings: { icon: Layers, color: "#818cf8" },
  "Conversational AI": { icon: Sparkles, color: "#a78bfa" },
  "AI Agents": { icon: Cpu, color: "#38bdf8" },
  "Agentic AI": { icon: Cpu, color: "#38bdf8" },
  LangChain: { icon: Layers, color: "#22c55e" },
  LangGraph: { icon: Layers, color: "#14b8a6" },
  LlamaIndex: { icon: BookOpen, color: "#f97316" },
  "Hugging Face": { icon: Cpu, color: "#facc15" },
  "AWS Bedrock": { icon: Server, color: "#ff9900" },
  "Azure OpenAI": { icon: Server, color: "#38bdf8" },
  "Llama 3": { icon: Cpu, color: "#a78bfa" },
  Claude: { icon: Sparkles, color: "#f59e0b" },
  "Amazon Titan Embeddings": { icon: Layers, color: "#ff9900" },
  FAISS: { icon: Database, color: "#60a5fa" },
  "OpenSearch Vector Database": { icon: Database, color: "#38bdf8" },
  "Document Ingestion": { icon: BookOpen, color: "#a78bfa" },
  "Embedding Pipelines": { icon: Layers, color: "#818cf8" },
  "Semantic Retrieval": { icon: Globe, color: "#60a5fa" },
  FastAPI: { icon: Zap, color: "#009688" },
  Flask: { icon: Server, color: "#ffffff" },
  "REST APIs": { icon: Globe, color: "#60a5fa" },
  SQL: { icon: Database, color: "#a78bfa" },
  JavaScript: { icon: Code2, color: "#f7df1e" },
  PostgreSQL: { icon: Database, color: "#336791" },
  DynamoDB: { icon: Database, color: "#4053d6" },
  Redis: { icon: Database, color: "#dc382d" },
  Celery: { icon: Activity, color: "#37814a" },
  MLflow: { icon: Activity, color: "#0194e2" },
  RAGAS: { icon: ShieldCheck, color: "#a78bfa" },
  Prometheus: { icon: Activity, color: "#e6522c" },
  Grafana: { icon: Activity, color: "#f46800" },
  "AWS Lambda": { icon: Server, color: "#ff9900" },
  "Amazon SQS": { icon: Zap, color: "#ff9900" },
  "API Gateway": { icon: Globe, color: "#ff9900" },
  IAM: { icon: ShieldCheck, color: "#ff9900" },
  S3: { icon: Database, color: "#ff9900" },
  Docker: { icon: Server, color: "#2496ed" },
  Kubernetes: { icon: Layers, color: "#326ce5" },
  "Deep Learning": { icon: Cpu, color: "#a78bfa" },
  "Computer Vision": { icon: Activity, color: "#38bdf8" },
  "Image Processing": { icon: Activity, color: "#38bdf8" },
  "Object Detection": { icon: Activity, color: "#38bdf8" },
  "Image Segmentation": { icon: Activity, color: "#38bdf8" },
};

export const PILLAR_ICONS = [Sparkles, Layers, Server, Database, Zap, Activity, ShieldCheck, Cpu, Globe, Wrench];
export const PILLAR_GRADIENT = "";
export const PILLAR_GLOW = "";

export const skills: SkillGroup[] = [
  {
    group: "Generative AI",
    items: ["LLMs", "RAG", "Prompt Engineering", "Tool Calling", "Semantic Search", "Embeddings", "Conversational AI", "AI Agents", "Agentic AI"],
  },
  {
    group: "Frameworks",
    items: ["LangChain", "LangGraph", "LlamaIndex", "Hugging Face"],
  },
  {
    group: "Platforms & Models",
    items: ["AWS Bedrock", "Azure OpenAI", "Llama 3", "Claude", "Amazon Titan Embeddings"],
  },
  {
    group: "Retrieval",
    items: ["FAISS", "OpenSearch Vector Database", "Document Ingestion", "Embedding Pipelines", "Semantic Retrieval"],
  },
  {
    group: "Backend",
    items: ["FastAPI", "Flask", "REST APIs", "Python", "SQL", "JavaScript"],
  },
  {
    group: "Data",
    items: ["PostgreSQL", "DynamoDB", "Redis"],
  },
  {
    group: "Evaluation",
    items: ["MLflow", "RAGAS", "Prometheus", "Grafana", "Model & Prompt Evaluation"],
  },
  {
    group: "Governance",
    items: ["Guardrails", "Human-in-the-Loop", "Access Control", "Audit Logging", "Traceability"],
  },
  {
    group: "Cloud",
    items: ["AWS Lambda", "Amazon SQS", "API Gateway", "IAM", "S3", "Azure Blob Storage", "Docker", "Kubernetes"],
  },
  {
    group: "Machine Learning",
    items: ["Deep Learning", "Computer Vision", "Image Processing", "Object Detection", "Image Segmentation"],
  },
];

export function getTechIcon(name: string) {
  const meta = SKILL_ICON_MAP[name];
  const Icon = meta?.icon ?? Code2;
  return <Icon className="text-primary" size={13} />;
}

export function getHighlightIcon(title: string) {
  const lower = title.toLowerCase();
  if (lower.includes("production") || lower.includes("engineering")) return <ShieldCheck className="h-4 w-4 text-primary shrink-0" />;
  if (lower.includes("retrieval") || lower.includes("backend")) return <Database className="h-4 w-4 text-primary shrink-0" />;
  return <Sparkles className="h-4 w-4 text-primary shrink-0" />;
}
