import type { Certification } from "@/types";

export const certifications: Certification[] = [
  {
    name: "AWS Certified Machine Learning Engineer – Associate",
    issuer: "AWS",
    year: "2026",
    credentialId: "",
    pdf: "",
  },
  {
    name: "Machine Learning with Python",
    issuer: "Great Learning Academy",
    year: "2026",
    credentialId: "",
    pdf: "",
  },
  {
    name: "Microsoft Azure AI Fundamentals (AI-900)",
    issuer: "Microsoft",
    year: "2026",
    credentialId: "",
    pdf: "",
  },
  {
    name: "Google Generative AI Fundamentals",
    issuer: "Google",
    year: "2026",
    credentialId: "",
    pdf: "",
  },
  {
    name: "NPTEL — Computer Networks and Internet Protocol",
    issuer: "NPTEL",
    year: "",
    credentialId: "",
    pdf: "",
  },
  {
    name: "NPTEL — Theory of Computation",
    issuer: "NPTEL",
    year: "",
    credentialId: "",
    pdf: "",
  },
  {
    name: "NPTEL — Introduction to Internet of Things",
    issuer: "NPTEL",
    year: "",
    credentialId: "",
    pdf: "",
  },
];
