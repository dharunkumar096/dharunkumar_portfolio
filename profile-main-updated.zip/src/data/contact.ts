import { Coffee, Briefcase, Code2, Sparkles, Github } from "lucide-react";
import { profile } from "./profile";

export const inquiryTopics = [
  {
    id: "coffee",
    label: "Coffee & Chat",
    icon: Coffee,
    hint: "Casual catch-up & networking",
    defaultSubject: "☕ Coffee & Quick Catch-up",
    starterMessage: "I'd love to connect, exchange ideas, and talk about engineering and AI.",
    closingNote: "Looking forward to connecting!",
  },
  {
    id: "career",
    label: "Career & Roles",
    icon: Briefcase,
    hint: "Opportunities & collaboration",
    defaultSubject: "💼 Career Opportunity",
    starterMessage: "I'd like to discuss an opportunity that aligns with your AI and engineering background.",
    closingNote: "Looking forward to connecting and discussing the next steps.",
  },
  {
    id: "engineering",
    label: "Engineering Sync",
    icon: Code2,
    hint: "Architecture & technical discussions",
    defaultSubject: "⚡ Engineering Sync",
    starterMessage: "I'd love to discuss generative AI, RAG, agents, system design, or a technical problem.",
    closingNote: "Looking forward to sharing engineering ideas.",
  },
  {
    id: "other",
    label: "Something Else",
    icon: Sparkles,
    hint: "Other inquiries & ideas",
    defaultSubject: "📬 General Inquiry",
    starterMessage: "Reaching out with a quick question or note.",
    closingNote: "Thanks for your time, and looking forward to hearing back!",
  },
] as const;

export const socialLinks = [
  {
    href: profile.links.github,
    icon: Github,
    label: "GitHub",
    handle: "@dharunkumar-engineer",
    color: "from-zinc-800 to-zinc-900 border-zinc-700/60",
    brandClass: "border-zinc-700 bg-zinc-900 text-zinc-200 hover:bg-zinc-700 hover:border-zinc-500 hover:text-white",
    iconClass: "text-zinc-300",
  },
] as const;

export const contactData = {
  emailSubject: "Portfolio inquiry",
  reachMe: { title: "Reach me" },
  connect: { label: "Connect" },
  whatHelps: {
    title: "What helps",
    description: "Context that makes our conversation more useful",
    items: [
      "Role and team context (product stage, constraints, timelines)",
      "What you need most: shipping, reliability, performance, AI workflows",
      "Interview process and what success looks like in 90 days",
    ],
  },
} as const;
