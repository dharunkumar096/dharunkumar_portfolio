import type { ExperienceItem } from "@/types";

export const experience: ExperienceItem[] = [
  {
    category: "Generative AI",
    company: "WNS Global Solutions",
    title: "Generative AI Intern",
    startDate: "Dec 2025",
    endDate: "Jun 2026",
    timeframe: "Dec 2025 — Jun 2026",
    location: "India",
    domains: ["Generative AI", "LLMs", "RAG", "Fraud Analysis"],
    summary:
      "Built Python-based document, retrieval, and AI-assisted decision workflows for enterprise use cases.",
    outcomes: [
      "Built document ingestion and preprocessing workflows using Python and LangChain for enterprise generative AI applications.",
      "Implemented semantic retrieval with FAISS to surface relevant information from structured and unstructured business data.",
      "Processed claim and transaction data in PostgreSQL, supporting validation, accuracy checks, and AI-assisted decision workflows.",
      "Designed and tested fraud-analysis workflows covering transaction patterns, customer information, compliance rules, and risk indicators.",
      "Evaluated AI-generated responses for consistency, relevance, and accuracy, and maintained audit logs to support traceability.",
    ],
    techStack: ["Python", "LangChain", "FAISS", "PostgreSQL", "Audit Logging"],
  },
];

export function getDisplayDuration(item: ExperienceItem): string {
  return item.timeframe ?? "";
}

export function getDisplayDateRange(item: ExperienceItem): string {
  return `${item.startDate} — ${item.endDate ?? "Present"}`;
}

export function getYearsExperience(
  items: ExperienceItem[],
  _includeInternship = false,
  _includeTraining = false,
): string {
  return items.length ? "0.5+" : "0";
}
