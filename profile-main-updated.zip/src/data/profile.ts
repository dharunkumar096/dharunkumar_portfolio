import type { Profile } from "@/types";
import { certifications } from "./certifications";

export const profile: Profile = {
  name: "Dharunkumar C",
  role: "AI Engineer",
  location: "India",
  phone: "+91 93443 55248",
  email: "dharunkumar.engineer@gmail.com",
  avatar: undefined,
  logo: "/default/Logo.webp",
  primaryCta: {
    label: "View Selected Work",
    href: "/projects",
  },
  resume: {
    pdfSrc: "/resume/Dharunkumar_C_Resume.pdf",
    pdfTitle: "Dharunkumar C Resume",
  },
  hero: {
    initials: "DC",
    headline: "Building practical generative AI systems for real-world workflows.",
    subhead:
      "I build Python-based generative AI systems — retrieval pipelines, multi-agent workflows, and LLM applications — for enterprise use cases like fraud investigation, claim adjudication, and document intelligence.",
  },
  links: {
    github: "https://github.com/dharunkumar-engineer",
    linkedin: "",
  },
  certifications,
  education: [
    {
      institution: "Parul University, Vadodara",
      degree: "Bachelor of Engineering in Information Technology",
      location: "Vadodara, Gujarat, India",
      startDate: "Jul 2022",
      endDate: "Jun 2026",
    },
  ],
};
