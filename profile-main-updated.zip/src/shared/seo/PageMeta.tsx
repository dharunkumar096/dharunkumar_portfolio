import { Helmet } from "react-helmet-async";
import { absolutePath, SITE_URL, GOOGLE_SITE_VERIFICATION } from "@/config/site";
import { profile } from "@/data/profile";

type PageMetaProps = {
  title: string;
  description: string;
  path: string;
  ogType?: "website" | "article" | "profile";
  keywords?: string[];
  image?: string;
  noindex?: boolean;
};

export function PageMeta({
  title,
  description,
  path,
  ogType = "website",
  keywords,
  image,
  noindex = false,
}: PageMetaProps) {
  const url = absolutePath(path);
  const fullTitle =
    path === "/" || path === ""
      ? `${profile.name} | ${profile.role}`
      : title.includes(profile.name)
        ? title
        : `${title} | ${profile.name}`;

  const allKeywords = [
    profile.name,
    profile.role,
    "Generative AI",
    "LLMs",
    "RAG",
    "AI Agents",
    "Agentic AI",
    "Python",
    "LangChain",
    "LangGraph",
    "AWS Bedrock",
    "Azure OpenAI",
    "FAISS",
    "OpenSearch",
    "Machine Learning",
    "Computer Vision",
    ...(keywords || []),
  ].join(", ");

  const imageUrl = image ? absolutePath(image) : undefined;

  const schemaOrgGraph: Record<string, unknown>[] = [
    {
      "@type": "Person",
      "@id": `${SITE_URL}/#person`,
      name: profile.name,
      url: `${SITE_URL}/`,
      jobTitle: profile.role,
      email: profile.email,
      telephone: profile.phone,
      sameAs: [profile.links.github, profile.links.linkedin].filter(Boolean),
      knowsAbout: [
        "Generative AI", "LLMs", "RAG", "AI Agents", "Python",
        "LangChain", "LangGraph", "AWS Bedrock", "Azure OpenAI",
        "FAISS", "OpenSearch", "Machine Learning", "Computer Vision",
      ],
      alumniOf: {
        "@type": "EducationalOrganization",
        name: "Parul University",
      },
    },
    {
      "@type": "WebSite",
      "@id": `${SITE_URL}/#website`,
      url: `${SITE_URL}/`,
      name: `${profile.name} - ${profile.role} Portfolio`,
      description,
      publisher: { "@id": `${SITE_URL}/#person` },
    },
  ];

  if (ogType === "article") {
    schemaOrgGraph.push({
      "@type": "Article",
      "@id": `${url}#article`,
      url,
      headline: fullTitle,
      description,
      ...(imageUrl ? { image: imageUrl } : {}),
      author: { "@id": `${SITE_URL}/#person` },
      mainEntityOfPage: url,
    });
  } else {
    schemaOrgGraph.push({
      "@type": path === "/" ? "ProfilePage" : "WebPage",
      "@id": `${url}#webpage`,
      url,
      name: fullTitle,
      description,
      isPartOf: { "@id": `${SITE_URL}/#website` },
      about: { "@id": `${SITE_URL}/#person` },
    });
  }

  const robotsContent = noindex
    ? "noindex, nofollow"
    : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1";

  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="title" content={fullTitle} />
      <meta name="description" content={description} />
      <meta name="keywords" content={allKeywords} />
      <meta name="author" content={profile.name} />
      <meta name="robots" content={robotsContent} />
      <meta name="googlebot" content={robotsContent} />
      <link rel="canonical" href={url} />

      {GOOGLE_SITE_VERIFICATION && (
        <meta name="google-site-verification" content={GOOGLE_SITE_VERIFICATION} />
      )}

      <meta property="og:type" content={ogType} />
      <meta property="og:url" content={url} />
      <meta property="og:site_name" content={`${profile.name} | ${profile.role}`} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      {imageUrl && <meta property="og:image" content={imageUrl} />}
      {ogType === "profile" && (
        <>
          <meta property="profile:first_name" content="Dharunkumar" />
          <meta property="profile:last_name" content="C" />
        </>
      )}

      <meta name="twitter:card" content={imageUrl ? "summary_large_image" : "summary"} />
      <meta name="twitter:url" content={url} />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      {imageUrl && <meta name="twitter:image" content={imageUrl} />}

      <script type="application/ld+json">
        {JSON.stringify({ "@context": "https://schema.org", "@graph": schemaOrgGraph })}
      </script>
    </Helmet>
  );
}
